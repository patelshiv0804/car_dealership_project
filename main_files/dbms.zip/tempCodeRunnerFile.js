
  }
  console.log('Connected to MySQL database as id ' + connection.threadId);
});

var bodyParser = require('body-parser');
